# ec-macros

This crate is a part of the [unhindered-ec](https://unhindered.ec) project.

Macros to be used primarily with the `ec-core` crate of the same project - please do not depend on this directly and instead use the re-exports from `ec-core` instead.
