# ec-linear

This crate is a part of the [unhindered-ec](https://unhindered.ec) project.

This crate provides implementations for basic linear evolution such as on bitstrings.
