# push-macros

This crate is a part of the [unhindered-ec](https://unhindered.ec) project.

Macros to be used with the `push` crate of the same project - please do not depend on this directly and instead use the re-exports from push instead.
