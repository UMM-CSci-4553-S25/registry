# ec-core

This crate is a part of the [unhindered-ec](https://unhindered.ec) project.

This crate provides core evolutionary computation functionality, such as interfaces for
- Individuals
- Generations
- Scorers
- Mutators
- Recombinators
- ...


