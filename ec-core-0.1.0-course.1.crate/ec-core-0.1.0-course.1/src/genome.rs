pub trait Genome {
    type Gene;
}
