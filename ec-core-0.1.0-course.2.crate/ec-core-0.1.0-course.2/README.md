# ec-core

The core data structures and algorithms for an evolutionary computation system.
