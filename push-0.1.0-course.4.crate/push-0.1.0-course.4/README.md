# push

This crate is a part of the [unhindered-ec](https://unhindered.ec) project.

This crate provides abstractions for basic push-based evolution, such as a push interpreter and basic integer and boolean instructions, as well as an interface to create your own.
