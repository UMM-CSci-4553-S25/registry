pub mod cmp;
pub mod dup;
pub mod flush;
pub mod is_empty;
pub mod pop;
pub mod push_value;
pub mod stack_depth;
pub mod swap;
