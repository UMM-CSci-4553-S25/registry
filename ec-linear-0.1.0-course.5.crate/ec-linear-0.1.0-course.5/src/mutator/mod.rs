pub mod umad;
pub mod with_one_over_length;
pub mod with_rate;
